# UTM SecureNotes — Design Specification
**Course:** SECR4483 Secure Programming — Group Project 2025/2026-02
**Date:** 2026-06-17
**Status:** Approved

---

## 1. Overview

UTM SecureNotes is a secure web application for Universiti Teknologi Malaysia graduate students to create, store, and share encrypted personal notes. Access is restricted to verified `@graduate.utm.my` accounts only. Notes are encrypted at rest using AES-256-GCM with per-note keys, and key exchange for sharing uses RSA-2048.

The system satisfies all three parts of the group project:
- **Part 1:** Authentication module (registration, OTP, login) — analyzed for vulnerabilities and secured
- **Part 2:** Transaction module (note CRUD + sharing) — analyzed for vulnerabilities and secured
- **Part 3:** Fully integrated secure application with ≥7 security controls

---

## 2. Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.12 + Flask |
| Database | MySQL 8 via SQLAlchemy ORM |
| Frontend | HTML + Bootstrap 5 + vanilla JavaScript |
| Cryptography | Python `cryptography` library (AES-256-GCM, PBKDF2, RSA-2048) |
| Forms & CSRF | Flask-WTF |
| Email (OTP) | Flask-Mail via SMTP |
| Input sanitization | `bleach` |
| Password hashing | `bcrypt` (cost factor 12) |

---

## 3. Architecture

```
Browser (HTML/JS)
      │  HTTPS (self-signed TLS in dev)
      ▼
Flask Application
  ├── auth Blueprint     (register, OTP, login, logout)
  ├── notes Blueprint    (CRUD, share)
  └── admin Blueprint    (user management, audit logs)
      │
      ▼
MySQL Database
  (users, otp_tokens, notes, note_keys, note_access, audit_logs)
```

**Project structure:**
```
SecureAppDevelopment/
├── app/
│   ├── __init__.py         # Flask app factory
│   ├── models.py           # SQLAlchemy models
│   ├── crypto.py           # AES-256-GCM + RSA helpers
│   ├── auth/               # Blueprint: register, login, OTP
│   │   ├── __init__.py
│   │   ├── routes.py
│   │   └── forms.py
│   ├── notes/              # Blueprint: CRUD, share
│   │   ├── __init__.py
│   │   ├── routes.py
│   │   └── forms.py
│   ├── admin/              # Blueprint: user mgmt, audit
│   │   ├── __init__.py
│   │   └── routes.py
│   └── templates/
│       ├── base.html
│       ├── auth/
│       ├── notes/
│       └── admin/
├── config.py
├── requirements.txt
└── run.py
```

---

## 4. User Roles

| Role | Capabilities |
|------|-------------|
| `student` | Register, login, create/read/update/delete own notes, share notes with other UTM students |
| `admin` | View all users, suspend/activate accounts, view audit logs. Cannot access note content (no note_keys rows for admin accounts). |

---

## 5. Database Schema

### `users`
| Column | Type | Notes |
|--------|------|-------|
| id | INT PK AUTO_INCREMENT | |
| email | VARCHAR(255) UNIQUE | Must end in `@graduate.utm.my` |
| password_hash | VARCHAR(255) | bcrypt, cost 12 |
| vault_salt | BINARY(32) | Random, used for PBKDF2 |
| rsa_public_key | TEXT | RSA-2048 public key (PEM) |
| rsa_private_key_encrypted | BLOB | RSA private key encrypted with vault_key |
| role | ENUM('student','admin') | Default: student |
| is_verified | BOOLEAN | False until OTP confirmed |
| is_active | BOOLEAN | Admin can set False to suspend |
| created_at | DATETIME | |
| last_login_at | DATETIME | |

### `otp_tokens`
| Column | Type | Notes |
|--------|------|-------|
| id | INT PK | |
| user_id | INT FK → users | |
| token_hash | VARCHAR(255) | bcrypt hash of 6-digit OTP |
| expires_at | DATETIME | 10-minute TTL |
| used | BOOLEAN | One-time use enforced |

### `notes`
| Column | Type | Notes |
|--------|------|-------|
| id | INT PK | |
| owner_id | INT FK → users | |
| title_ciphertext | BLOB | AES-256-GCM encrypted |
| body_ciphertext | BLOB | AES-256-GCM encrypted |
| nonce | BINARY(12) | Random per encryption |
| created_at | DATETIME | |
| updated_at | DATETIME | |

### `note_keys`
| Column | Type | Notes |
|--------|------|-------|
| id | INT PK | |
| note_id | INT FK → notes | |
| user_id | INT FK → users | One row per (note, user) pair |
| encrypted_note_key | BLOB | Note AES key wrapped with user's vault_key or RSA public key |
| key_nonce | BINARY(12) | Nonce used when wrapping the note key (vault-type rows only) |
| key_type | ENUM('vault','rsa') | How it was wrapped |

### `note_access`
| Column | Type | Notes |
|--------|------|-------|
| note_id | INT FK → notes | |
| user_id | INT FK → users | |
| permission | ENUM('read','write') | |
| shared_at | DATETIME | |

### `audit_logs`
| Column | Type | Notes |
|--------|------|-------|
| id | INT PK | |
| user_id | INT FK → users | |
| action | VARCHAR(100) | e.g. 'login', 'note_create', 'share_note', 'login_failed' |
| ip_address | VARCHAR(45) | IPv4/IPv6 |
| user_agent | TEXT | |
| created_at | DATETIME | |

---

## 6. Authentication & OTP Flow

### Registration
1. User submits email + password via form
2. Server validates:
   - Email matches regex `^[a-zA-Z0-9._%+\-]+@graduate\.utm\.my$`
   - Password policy: ≥12 chars, at least one uppercase, lowercase, digit, and symbol
3. Password hashed with `bcrypt` (cost 12)
4. `vault_salt` = `os.urandom(32)`
5. RSA-2048 keypair generated; private key encrypted with `vault_key` (derived immediately from submitted password)
6. User saved with `is_verified=False`
7. 6-digit OTP generated → bcrypt hashed → stored in `otp_tokens` (10-min TTL)
8. OTP sent to UTM email via SMTP
9. User submits OTP → server verifies hash → `is_verified=True`

### Login
1. User submits email + password
2. Check: user exists, `is_verified=True`, `is_active=True`
3. `bcrypt.verify(password, password_hash)`
4. On success:
   - Derive `vault_key = PBKDF2HMAC(SHA-256, password, vault_salt, 600_000 iterations)`
   - Store `vault_key` in server-side session (signed Flask cookie)
   - Regenerate session ID (prevents session fixation)
   - Log `login` to `audit_logs`
5. On failure:
   - Log `login_failed` to `audit_logs`
   - Generic error message (no user enumeration)
   - Rate limit: 5 failed attempts → 15-minute lockout

### Session Management
- Inactivity timeout: 30 minutes
- Session ID regenerated on login and privilege change
- Logout clears `vault_key` from session immediately
- CSRF token on every state-changing form (Flask-WTF)

---

## 7. Encryption Architecture (SEAL Layer)

### Vault Key
Derived on every successful login — never stored in the database:
```
vault_key = PBKDF2HMAC(
    algorithm  = SHA-256,
    length     = 32,
    salt       = user.vault_salt,
    iterations = 600_000
)(password)
```

### Creating a Note
```
note_key  = os.urandom(32)                          # random AES-256 key
nonce     = os.urandom(12)                          # random GCM nonce
title_ct  = AES_256_GCM.encrypt(note_key, nonce, title_plaintext)
body_ct   = AES_256_GCM.encrypt(note_key, nonce, body_plaintext)

key_nonce             = os.urandom(12)
encrypted_note_key    = AES_256_GCM.encrypt(vault_key, key_nonce, note_key)

→ INSERT notes (title_ct, body_ct, nonce)
→ INSERT note_keys (note_id, user_id, encrypted_note_key, key_type='vault')
```

### Reading a Note
```
encrypted_note_key = SELECT FROM note_keys WHERE note_id AND user_id
note_key           = AES_256_GCM.decrypt(vault_key, encrypted_note_key)
plaintext          = AES_256_GCM.decrypt(note_key, nonce, ciphertext)
→ serve plaintext in response (never written to disk)
```

### Sharing a Note
```
# Sharer already holds note_key (unwrapped from their note_keys row)
recipient_pub_key     = SELECT rsa_public_key FROM users WHERE email = recipient_email
encrypted_note_key    = RSA_OAEP.encrypt(recipient_pub_key, note_key)

→ INSERT note_keys (note_id, recipient_id, encrypted_note_key, key_type='rsa')
→ INSERT note_access (note_id, recipient_id, permission)
```
When recipient logs in, they decrypt the RSA-wrapped note key using their RSA private key (which they unwrap from `rsa_private_key_encrypted` using their `vault_key`).

---

## 8. Routes

### Auth Blueprint (`/auth`)
| Method | Path | Action |
|--------|------|--------|
| GET/POST | `/auth/register` | Registration form + submit |
| GET/POST | `/auth/verify-otp` | OTP entry form + submit |
| POST | `/auth/resend-otp` | Rate-limited OTP resend |
| GET/POST | `/auth/login` | Login form + submit |
| POST | `/auth/logout` | Clear session |

### Notes Blueprint (`/notes`)
| Method | Path | Action |
|--------|------|--------|
| GET | `/notes/` | List note titles (decrypt titles only) |
| GET/POST | `/notes/new` | Create note form + submit |
| GET | `/notes/<id>` | View note (decrypt + render) |
| GET/POST | `/notes/<id>/edit` | Edit note (owner only) |
| POST | `/notes/<id>/delete` | Delete note + all note_keys (owner only) |
| GET/POST | `/notes/<id>/share` | Share note with another UTM student |

### Admin Blueprint (`/admin`)
| Method | Path | Action |
|--------|------|--------|
| GET | `/admin/users` | List all users + status |
| POST | `/admin/users/<id>/suspend` | Set `is_active=False` |
| POST | `/admin/users/<id>/activate` | Set `is_active=True` |
| GET | `/admin/audit-logs` | Paginated audit log view |

---

## 9. Access Control Rules

Every request to `/notes` enforces:
- `is_authenticated AND is_verified AND is_active`

Per-operation checks:
- Edit/delete: `note.owner_id == current_user.id`
- Read shared note: `note_access` row exists for `current_user.id`
- All `/admin` routes: `current_user.role == 'admin'` (Flask decorator)
- Admin accounts have no `note_keys` rows — cryptographically barred from note content

---

## 10. Security Controls (Part 3 Rubric)

| # | Control | Implementation |
|---|---------|---------------|
| 1 | Input validation & output sanitization | `bleach` strips HTML on all input before encryption; Jinja2 auto-escaping on all output |
| 2 | Multi-factor authentication | Email OTP required on registration; optional OTP on login |
| 3 | Role-based access control | `student` vs `admin` enforced via decorator on every route |
| 4 | Secure session management | 30-min timeout, session regeneration on login, CSRF tokens (Flask-WTF) |
| 5 | Encrypted storage | AES-256-GCM per-note keys + RSA-2048 key wrapping for sharing |
| 6 | Secure transmission | Self-signed TLS (HTTPS) in development |
| 7 | Error handling | Generic messages only, no stack traces in production, no user enumeration |

---

## 11. Assignment Coverage Map

| Assignment Part | Coverage |
|----------------|----------|
| Part 1 — Auth Module Analysis (5 marks) | Analyze registration + login for SQLi, XSS, weak passwords, session risks. Show naive vulnerable version vs. our secure implementation as the fix. |
| Part 2 — Transaction Module Analysis (5 marks) | Analyze note CRUD + sharing for session fixation, authorization gaps, client-side state manipulation, sanitization flaws. Show naive vs. secure. |
| Part 3 — Integrated Secure App (7 marks) | Full UTM SecureNotes: functional auth + transactions, all 7 security elements, Burp Suite/OWASP ZAP testing, technical report. |
| Video Presentation (3 marks) | Demo: register → OTP verify → login → create note → view encrypted DB → share note → admin panel → security walkthrough. |

---

## 12. Input Sanitization & Error Handling

- All user text input processed through `bleach.clean()` before encryption
- SQLAlchemy ORM parameterizes all queries (no raw SQL)
- Jinja2 templates use `{{ var }}` auto-escaping (XSS prevention)
- No raw exception messages exposed to users
- `flask run --no-debugger` in production mode
- HTTP security headers: `X-Content-Type-Options`, `X-Frame-Options`, `Content-Security-Policy`

---

## 13. Vulnerability Testing Plan

Tools: **Burp Suite Community** or **OWASP ZAP**

| Test | Tool | What to show |
|------|------|-------------|
| SQL injection on login | Burp Suite Repeater | Parameterized queries block it |
| XSS in note title/body | OWASP ZAP active scan | bleach + Jinja2 escaping blocks it |
| Session fixation | Burp Suite | Session ID changes on login |
| CSRF on note delete | Burp Suite | CSRF token validation rejects forged requests |
| Brute force login | Burp Suite Intruder | Rate limit + lockout triggers |
| Unauthorized note access | Manual | 403 returned, no data leaked |
