# Design: Signed Transaction Receipts

**Date:** 2026-07-05
**Status:** Approved (design), pending implementation plan
**Component:** `app/notes` (transaction module) + `app/crypto`

## Summary

Add a **transaction module** to UTM SecureNotes. Every time a note is shared
(sender → receiver), the app records a **signed, tamper-evident transaction
receipt**. The receipt captures four fields — file name, sender, receiver, and
time — and is downloadable **only by the two parties** (sender and receiver).
Admins are excluded. The receipt is digitally signed with the **sender's RSA
private key**, giving non-repudiation: the sender provably authorized the share.

This maps directly to the SECR4483 rubric's "transaction module analysis"
deliverable.

## Goals

- Create a persistent, per-share transaction record.
- Sign each receipt with the sender's RSA-2048 private key (non-repudiation +
  integrity).
- Let both sender and receiver — and only them — download a receipt as a file.
- Keep the note title ("file name") encrypted at rest, consistent with the
  app's zero-plaintext-content ethos (admins/DB readers must not see titles).
- Make each receipt self-contained so it survives note edits and note deletion.

## Non-Goals

- Receipts for any event other than sharing a note (no receipts for
  create/edit/delete).
- Admin access to receipt contents (admins keep only the existing `note_share`
  audit-log entry, which is metadata only).
- Revocation / deletion of receipts (out of scope for v1).
- Re-signing or updating a receipt when a note is later edited — a receipt is a
  point-in-time snapshot of the share event.

## Key Design Decisions

1. **Signed, tamper-evident receipt** (not plain, not fully encrypted). The
   receipt's fields are signed so any alteration is detectable by either party.
2. **Signed with the sender's RSA private key.** Verified with the sender's
   public key → proves the *sender* authorized the share (non-repudiation),
   reusing the app's existing per-user RSA keypairs. Signing happens at share
   time, when the sender is logged in and their private key is decryptable via
   the in-session vault key.
3. **Title stays encrypted at rest.** The "file name" is the note's real title;
   it is never stored in plaintext.
4. **Self-contained receipts.** Rather than regenerating the title from the live
   note (which breaks — see below), each transaction row stores its own
   encrypted snapshot of the title. This keeps the receipt valid across note
   edits and note deletion.
5. **Two parties only.** Only the sender or receiver can list and download their
   receipts. Admins are excluded from the receipts feature.

### Why self-contained instead of regenerate-from-note

The original idea was to store only metadata + signature and re-derive the title
from the note at download time. Two properties of the existing code make that
unworkable:

- **Edits rotate keys.** `edit_note` (`app/notes/routes.py:146`) generates a new
  note key + nonce and re-wraps only for the editor. After an edit, neither the
  share-time title nor (for stale RSA recipients) the note itself is
  reproducible.
- **Deletes cascade.** Deleting a note cascade-deletes its `note_keys`
  (`app/models.py:39`). A receipt that depends on the note would break, but a
  transaction record must outlive the note.

The fix: at share time, snapshot the title into the transaction row, encrypted
under a fresh per-transaction key `K_t`, with `K_t` wrapped for both parties
(AES-GCM under the sender's vault key; RSA-OAEP under the receiver's public
key). This mirrors the existing note-key mechanism, scoped to the receipt. The
title is still never plaintext at rest, and the receipt is independent of the
note's later state.

## Data Model

New table `transactions` (`app/models.py`):

| Column | Type | Notes |
|--------|------|-------|
| `id` | Integer PK | |
| `note_id` | Integer FK `notes.id`, nullable | `ON DELETE SET NULL` — receipt outlives the note |
| `sender_id` | Integer FK `users.id`, not null | |
| `receiver_id` | Integer FK `users.id`, not null | |
| `sender_email` | String(255), not null | Snapshot; one of the signed values |
| `receiver_email` | String(255), not null | Snapshot; one of the signed values |
| `created_at` | DateTime, default `utcnow` | The "time" field |
| `filename_ciphertext` | LargeBinary, not null | AES-256-GCM(title) under `K_t` |
| `filename_nonce` | LargeBinary(12), not null | Nonce for `filename_ciphertext` |
| `kt_sender_wrapped` | LargeBinary, not null | `K_t` wrapped with sender's vault key |
| `kt_sender_nonce` | LargeBinary(12), not null | Nonce for `kt_sender_wrapped` |
| `kt_receiver_wrapped` | LargeBinary, not null | `K_t` RSA-OAEP-wrapped with receiver's public key |
| `signature` | LargeBinary, not null | RSA-PSS/SHA-256 over canonical JSON, by sender's private key |

Notes:
- `note_id` uses `SET NULL` (not cascade) so deleting a note does not delete its
  receipts. All fields needed to render/verify a receipt live in the transaction
  row itself.
- `sender_email` / `receiver_email` are snapshotted so the signed message is
  stable even if a user's email were ever changed.

## Crypto Additions

Add to `app/crypto.py`, using RSA-PSS with SHA-256 (MGF1-SHA256):

- `rsa_sign(private_pem: bytes, message: bytes) -> bytes`
- `rsa_verify(public_pem: bytes, message: bytes, signature: bytes) -> bool`
  (returns `False` on an invalid signature rather than raising).

These reuse the `cryptography` primitives already imported in `crypto.py`.

## Canonical Signed Message

The signature is computed over a **canonical JSON** serialization (sorted keys,
no insignificant whitespace, UTF-8) of exactly:

```json
{"file_name": <title>, "sender": <sender_email>, "receiver": <receiver_email>, "time": <created_at ISO-8601 UTC>}
```

Both signing (share time) and verification (download time) build this identical
structure so bytes match. `created_at` is serialized as ISO-8601 in UTC.

## Flows

### Share time — extend `share_note` (`app/notes/routes.py:183`)

Inside the existing successful-share branch (after the `NoteKey` + `NoteAccess`
rows are added), in the **same commit/transaction**:

1. Decrypt the note title: `title = aes_decrypt(note_key, note.nonce, note.title_ciphertext)`.
2. Generate `K_t = generate_note_key()` and a nonce; `filename_ciphertext = aes_encrypt(K_t, nonce, title)`.
3. Wrap `K_t`:
   - sender: `wrap_key_with_vault(vault_key, K_t)` → `(kt_sender_nonce, kt_sender_wrapped)`
   - receiver: `rsa_encrypt_key(recipient.rsa_public_key, K_t)` → `kt_receiver_wrapped`
4. Build the canonical JSON (title = decrypted plaintext, emails, `created_at`).
5. Decrypt the sender's RSA private key
   (`aes_decrypt_sealed(vault_key, user.rsa_private_key_encrypted)`) and
   `signature = rsa_sign(private_pem, canonical_json)`.
6. Insert the `Transaction` row.
7. Audit: add a `transaction_create` audit-log entry alongside the existing
   `note_share`.

### Download — `GET /notes/transactions/<int:tx_id>/download`

1. `login_required`. Load the transaction or 404.
2. Authorize: the current user must be `sender_id` **or** `receiver_id`, else
   `abort(403)`. (Admins are not exempt — receipts are two-party only.)
3. Recover `K_t`:
   - if requester is sender: `unwrap_key_with_vault(vault_key, kt_sender_nonce, kt_sender_wrapped)`
   - if requester is receiver: decrypt their RSA private key with the vault key,
     then `rsa_decrypt_key(private_pem, kt_receiver_wrapped)`
4. Decrypt the filename: `title = aes_decrypt(K_t, filename_nonce, filename_ciphertext)`.
5. Rebuild the canonical JSON and `rsa_verify(sender.rsa_public_key, canonical, signature)`.
   - On failure: do **not** serve the file; flash a tampering warning / return an
     error. (Demonstrates integrity protection.)
6. On success: serve a downloadable file `transaction-<tx_id>.json` (attachment)
   containing the four fields plus `signature` (base64), the signature algorithm
   identifier, and the sender's public key for independent verification.
7. Audit: add a `transaction_download` entry.

### List — `GET /notes/transactions`

1. `login_required`. Query transactions where `sender_id == me` or
   `receiver_id == me`.
2. For each, decrypt the filename with the requester's wrapped `K_t` to show the
   title. Split into "Sent" and "Received".
3. Render each row: title, counterparty email, timestamp, and a Download button.
4. Add a "Transactions" link to the base-template nav (`app/templates/base.html`)
   for logged-in users.

## Access Control & Admin

- Listing and downloading are restricted to the transaction's sender or receiver.
  A third party or an admin receives `403` with no receipt data.
- No `transactions` route is exposed under `/admin`. The existing `note_share`
  audit-log entry continues to record that a share happened (metadata only,
  never the title or receipt contents).

## Error Handling

- Missing transaction → 404.
- Unauthorized requester → 403 (no leaked fields).
- Signature verification failure at download → refuse to serve; surface a clear
  tampering message; record the event.
- Decryption failure (e.g., corrupted row) → generic error, no stack trace
  (consistent with existing error handlers).

## Testing (`tests/test_transactions.py`)

1. **Round-trip / non-repudiation:** share a note; both sender and receiver can
   download; the served JSON verifies against the sender's public key; fields
   (file name, sender, receiver, time) are correct.
2. **Tamper detection:** mutate `signature` or `filename_ciphertext` in the DB →
   download refuses / verification returns `False`.
3. **Two-party-only access:** a third student and an admin both get 403 on list
   scope (see own only) and on download of someone else's receipt.
4. **Survives note edit:** edit the note after sharing → receipt still downloads
   and shows the share-time title, still verifies.
5. **Survives note deletion:** delete the note → receipt row persists
   (`note_id` NULL) and still downloads/verifies.
6. **Crypto unit tests:** `rsa_sign`/`rsa_verify` round-trip; verify returns
   `False` for a wrong key or altered message.

## Rubric Mapping

- **Transaction module analysis:** signed receipts provide integrity +
  non-repudiation of the share event; downloadable evidence for the demo.
- **Confidentiality:** title stays encrypted at rest; only the two parties can
  read the receipt; admins cannot.
- **Access control:** third-party/admin download returns 403.

## Local Run Enablement (make the app runnable for the demo)

The feature is built and verified entirely via `pytest` on in-memory SQLite and
needs no live database. This section covers the *separate, follow-on* work of
making the app clickable in a browser for the video-demo walkthrough, without
requiring a MySQL install or working SMTP.

Three gaps to close:

1. **Local database (no MySQL).** Add a `DevConfig(Config)` that overrides
   `SQLALCHEMY_DATABASE_URI` to a local SQLite file
   (`sqlite:///securenotes.db`). Like `TestConfig`, it also provides safe
   defaults for the env vars `Config` reads unconditionally (`SECRET_KEY`,
   `MAIL_USERNAME`, `MAIL_PASSWORD`) and sets `SESSION_COOKIE_SECURE` to work
   over the local adhoc-TLS server. Selected via an env var (e.g.
   `FLASK_CONFIG=dev`) or a `run.py` flag — production still defaults to
   `Config`/MySQL.

2. **Table creation.** The app factory has no `db.create_all()` and there are no
   migrations, so a live DB starts empty. Add a one-off `flask`/CLI command or a
   small `init_db` script that creates all tables (dev/SQLite only). Do **not**
   auto-`create_all` on every request/startup in production.

3. **OTP without SMTP.** Registration emails a 6-digit OTP; locally that email
   never arrives, blocking the golden path. Add a dev-only OTP echo gated behind
   a config flag (e.g. `OTP_DEV_ECHO = True`, on in `DevConfig`, off in `Config`)
   that surfaces the OTP via the server log and/or a flash message so the demo
   can proceed. Production behavior (email only, never echoed) is unchanged.

**Decisions:**
- SQLite file for local run (no MySQL install); MySQL remains the production
  target via the default `Config`.
- Dev-only OTP echo behind a flag rather than requiring real Gmail credentials
  (real SMTP remains an option for anyone who sets `MAIL_*`).
- All three behaviors are strictly opt-in via config so production security is
  never weakened.

**Testing:** a smoke test that boots the app under `DevConfig`, creates tables,
registers → reads the echoed OTP → verifies → logs in → creates/shares a note →
downloads a receipt. (SQLite in a temp file, still no external services.)
