from flask import Blueprint
bp = Blueprint('notes', __name__)
from . import routes  # noqa: F401, E402
