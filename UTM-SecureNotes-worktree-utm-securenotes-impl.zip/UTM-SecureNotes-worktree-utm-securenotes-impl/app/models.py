from datetime import datetime
from .extensions import db

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    vault_salt = db.Column(db.LargeBinary(32), nullable=False)
    rsa_public_key = db.Column(db.Text, nullable=True)
    rsa_private_key_encrypted = db.Column(db.LargeBinary, nullable=True)
    role = db.Column(db.String(10), default='student', nullable=False)
    is_verified = db.Column(db.Boolean, default=False, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login_at = db.Column(db.DateTime, nullable=True)

    otp_tokens = db.relationship('OTPToken', backref='user', lazy=True, cascade='all, delete-orphan')
    owned_notes = db.relationship('Note', backref='owner', lazy=True, foreign_keys='Note.owner_id')

class OTPToken(db.Model):
    __tablename__ = 'otp_tokens'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    token_hash = db.Column(db.String(255), nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False, nullable=False)

class Note(db.Model):
    __tablename__ = 'notes'
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title_ciphertext = db.Column(db.LargeBinary, nullable=False)
    body_ciphertext = db.Column(db.LargeBinary, nullable=False)
    nonce = db.Column(db.LargeBinary(12), nullable=False)
    body_nonce = db.Column(db.LargeBinary(12), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    note_keys = db.relationship('NoteKey', backref='note', lazy=True, cascade='all, delete-orphan')
    access_list = db.relationship('NoteAccess', backref='note', lazy=True, cascade='all, delete-orphan')

class NoteKey(db.Model):
    __tablename__ = 'note_keys'
    id = db.Column(db.Integer, primary_key=True)
    note_id = db.Column(db.Integer, db.ForeignKey('notes.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    encrypted_note_key = db.Column(db.LargeBinary, nullable=False)
    key_nonce = db.Column(db.LargeBinary(12), nullable=True)  # set for key_type='vault'; null for 'rsa' (OAEP has no nonce)
    key_type = db.Column(db.String(5), nullable=False)  # 'vault' or 'rsa'

class NoteAccess(db.Model):
    __tablename__ = 'note_access'
    note_id = db.Column(db.Integer, db.ForeignKey('notes.id'), primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    permission = db.Column(db.String(5), nullable=False)  # 'read' or 'write'
    shared_at = db.Column(db.DateTime, default=datetime.utcnow)

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(100), nullable=False)
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Transaction(db.Model):
    __tablename__ = 'transactions'
    id = db.Column(db.Integer, primary_key=True)
    note_id = db.Column(db.Integer, db.ForeignKey('notes.id', ondelete='SET NULL'), nullable=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    sender_email = db.Column(db.String(255), nullable=False)
    receiver_email = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    filename_ciphertext = db.Column(db.LargeBinary, nullable=False)
    filename_nonce = db.Column(db.LargeBinary(12), nullable=False)
    kt_sender_wrapped = db.Column(db.LargeBinary, nullable=False)
    kt_sender_nonce = db.Column(db.LargeBinary(12), nullable=False)
    kt_receiver_wrapped = db.Column(db.LargeBinary, nullable=False)
    signature = db.Column(db.LargeBinary, nullable=False)
