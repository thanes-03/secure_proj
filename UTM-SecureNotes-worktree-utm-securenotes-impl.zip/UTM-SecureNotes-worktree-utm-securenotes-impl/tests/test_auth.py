import os
from unittest.mock import patch
from app.models import User, OTPToken
from app.extensions import db as _db
from app.crypto import derive_vault_key


def _register(client, email='a@graduate.utm.my', password='SecurePass1!xyz'):
    return client.post('/auth/register', data={
        'email': email,
        'password': password,
    }, follow_redirects=False)


def test_register_valid_email(client, app, db):
    with patch('app.auth.routes.mail'):
        resp = _register(client)
    assert resp.status_code == 302
    assert '/auth/verify-otp' in resp.headers['Location']
    with app.app_context():
        user = User.query.filter_by(email='a@graduate.utm.my').first()
        assert user is not None
        assert user.is_verified is False


def test_register_rejects_non_utm_email(client, app, db):
    resp = _register(client, email='attacker@gmail.com')
    assert resp.status_code == 200
    assert b'graduate.utm.my' in resp.data


def test_register_rejects_weak_password(client, app, db):
    resp = _register(client, password='weak')
    assert resp.status_code == 200


def test_verify_otp_correct(client, app, db):
    with patch('app.auth.routes.mail'):
        _register(client)
    with app.app_context():
        user = User.query.filter_by(email='a@graduate.utm.my').first()
        otp_record = OTPToken.query.filter_by(user_id=user.id, used=False).first()
    # Can't check real OTP hash without knowing the OTP — test the invalid path
    resp = client.post('/auth/verify-otp', data={'token': '000000'})
    assert resp.status_code == 200
    assert b'Invalid' in resp.data or b'invalid' in resp.data


def test_login_valid(client, app, db):
    with patch('app.auth.routes.mail'):
        _register(client, email='b@graduate.utm.my')
    with app.app_context():
        user = User.query.filter_by(email='b@graduate.utm.my').first()
        user.is_verified = True
        _db.session.commit()
    resp = client.post('/auth/login', data={
        'email': 'b@graduate.utm.my',
        'password': 'SecurePass1!xyz',
    }, follow_redirects=False)
    assert resp.status_code == 302
    assert '/notes/' in resp.headers['Location']


def test_login_wrong_password(client, app, db):
    with patch('app.auth.routes.mail'):
        _register(client, email='c@graduate.utm.my')
    with app.app_context():
        user = User.query.filter_by(email='c@graduate.utm.my').first()
        user.is_verified = True
        _db.session.commit()
    resp = client.post('/auth/login', data={
        'email': 'c@graduate.utm.my',
        'password': 'WrongPassword1!',
    })
    assert resp.status_code == 200
    assert b'Invalid' in resp.data or b'invalid' in resp.data


def test_login_unverified_blocked(client, app, db):
    with patch('app.auth.routes.mail'):
        _register(client, email='d@graduate.utm.my')
    resp = client.post('/auth/login', data={
        'email': 'd@graduate.utm.my',
        'password': 'SecurePass1!xyz',
    })
    assert resp.status_code == 200
    assert b'Invalid' in resp.data or b'invalid' in resp.data


def test_logout_clears_session(client, app, db):
    with patch('app.auth.routes.mail'):
        _register(client, email='e@graduate.utm.my')
    with app.app_context():
        user = User.query.filter_by(email='e@graduate.utm.my').first()
        user.is_verified = True
        _db.session.commit()
    client.post('/auth/login', data={'email': 'e@graduate.utm.my', 'password': 'SecurePass1!xyz'})
    client.post('/auth/logout')
    resp = client.get('/notes/', follow_redirects=False)
    assert resp.status_code == 302
