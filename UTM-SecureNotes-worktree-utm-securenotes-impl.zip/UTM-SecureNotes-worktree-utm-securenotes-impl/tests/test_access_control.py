def test_login_required_redirects_unauthenticated(client):
    response = client.get('/notes/', follow_redirects=False)
    assert response.status_code == 302
    assert '/auth/login' in response.headers['Location']

def test_admin_required_returns_403_for_student(client, app, db):
    from app.models import User
    from app.extensions import db as _db
    import os
    with app.app_context():
        user = User(
            email='student@graduate.utm.my',
            password_hash='h',
            vault_salt=os.urandom(32),
            role='student',
            is_verified=True,
        )
        _db.session.add(user)
        _db.session.commit()
        with client.session_transaction() as sess:
            sess['user_id'] = user.id
            sess['vault_key'] = os.urandom(32).hex()
    response = client.get('/admin/users')
    assert response.status_code == 403

def test_login_required_redirects_inactive_or_unverified_user(client, app, db):
    from app.models import User
    from app.extensions import db as _db
    import os
    with app.app_context():
        user = User(
            email='unverified@graduate.utm.my',
            password_hash='h',
            vault_salt=os.urandom(32),
            role='student',
            is_active=True,
            is_verified=False,
        )
        _db.session.add(user)
        _db.session.commit()
        with client.session_transaction() as sess:
            sess['user_id'] = user.id
            sess['vault_key'] = os.urandom(32).hex()
    response = client.get('/notes/', follow_redirects=False)
    assert response.status_code == 302
    assert '/auth/login' in response.headers['Location']

def test_login_required_allows_active_verified_user(client, app, db):
    from app.models import User
    from app.extensions import db as _db
    import os
    with app.app_context():
        user = User(
            email='valid@graduate.utm.my',
            password_hash='h',
            vault_salt=os.urandom(32),
            role='student',
            is_active=True,
            is_verified=True,
        )
        _db.session.add(user)
        _db.session.commit()
        with client.session_transaction() as sess:
            sess['user_id'] = user.id
            sess['vault_key'] = os.urandom(32).hex()
    response = client.get('/notes/')
    assert response.status_code == 200

def test_security_headers_present(client):
    resp = client.get('/auth/login')
    assert resp.headers.get('X-Content-Type-Options') == 'nosniff'
    assert resp.headers.get('X-Frame-Options') == 'DENY'
    assert 'Content-Security-Policy' in resp.headers

def test_csrf_token_present_in_form(client):
    resp = client.get('/auth/login')
    assert b'csrf_token' in resp.data
