import os
import pytest
from app.crypto import (
    generate_nonce, aes_encrypt, aes_decrypt,
    aes_encrypt_sealed, aes_decrypt_sealed,
    derive_vault_key,
    wrap_key_with_vault, unwrap_key_with_vault,
    generate_rsa_keypair, rsa_encrypt_key, rsa_decrypt_key,
    generate_note_key,
)

def test_aes_roundtrip():
    key = os.urandom(32)
    nonce = generate_nonce()
    plaintext = b'secret note content'
    ciphertext = aes_encrypt(key, nonce, plaintext)
    assert aes_decrypt(key, nonce, ciphertext) == plaintext

def test_generate_nonce_unique():
    assert generate_nonce() != generate_nonce()

def test_aes_ciphertext_length():
    key = os.urandom(32)
    nonce = generate_nonce()
    plaintext = b'hello'
    ciphertext = aes_encrypt(key, nonce, plaintext)
    # len(plaintext) + 16 GCM tag (nonce stored separately, not prepended)
    assert len(ciphertext) == len(plaintext) + 16

def test_aes_tamper_detection():
    key = os.urandom(32)
    nonce = generate_nonce()
    ciphertext = bytearray(aes_encrypt(key, nonce, b'data'))
    ciphertext[-1] ^= 0xFF  # flip last byte of GCM tag
    with pytest.raises(Exception):
        aes_decrypt(key, nonce, bytes(ciphertext))

def test_aes_sealed_roundtrip():
    key = os.urandom(32)
    plaintext = b'rsa private key pem bytes'
    blob = aes_encrypt_sealed(key, plaintext)
    assert aes_decrypt_sealed(key, blob) == plaintext

def test_aes_sealed_produces_unique_nonces():
    key = os.urandom(32)
    blob1 = aes_encrypt_sealed(key, b'same')
    blob2 = aes_encrypt_sealed(key, b'same')
    assert blob1[:12] != blob2[:12]

def test_derive_vault_key_deterministic():
    salt = os.urandom(32)
    k1 = derive_vault_key('MyPass1!AbcDef', salt)
    k2 = derive_vault_key('MyPass1!AbcDef', salt)
    assert k1 == k2
    assert len(k1) == 32

def test_derive_vault_key_different_passwords():
    salt = os.urandom(32)
    k1 = derive_vault_key('Password1!', salt)
    k2 = derive_vault_key('Password2!', salt)
    assert k1 != k2

def test_key_wrapping_roundtrip():
    vault_key = os.urandom(32)
    note_key = os.urandom(32)
    key_nonce, wrapped = wrap_key_with_vault(vault_key, note_key)
    assert unwrap_key_with_vault(vault_key, key_nonce, wrapped) == note_key

def test_rsa_key_roundtrip():
    private_pem, public_pem = generate_rsa_keypair()
    note_key = os.urandom(32)
    encrypted = rsa_encrypt_key(public_pem, note_key)
    decrypted = rsa_decrypt_key(private_pem, encrypted)
    assert decrypted == note_key

def test_generate_note_key_length():
    key = generate_note_key()
    assert len(key) == 32

def test_generate_note_key_unique():
    assert generate_note_key() != generate_note_key()

def test_rsa_sign_verify_roundtrip():
    from app.crypto import generate_rsa_keypair, rsa_sign, rsa_verify
    private_pem, public_pem = generate_rsa_keypair()
    message = b'{"file_name":"note","sender":"a","receiver":"b","time":"t"}'
    sig = rsa_sign(private_pem, message)
    assert rsa_verify(public_pem, message, sig) is True

def test_rsa_verify_rejects_altered_message():
    from app.crypto import generate_rsa_keypair, rsa_sign, rsa_verify
    private_pem, public_pem = generate_rsa_keypair()
    sig = rsa_sign(private_pem, b'original')
    assert rsa_verify(public_pem, b'tampered', sig) is False

def test_rsa_verify_rejects_wrong_key():
    from app.crypto import generate_rsa_keypair, rsa_sign, rsa_verify
    priv1, _ = generate_rsa_keypair()
    _, pub2 = generate_rsa_keypair()
    sig = rsa_sign(priv1, b'msg')
    assert rsa_verify(pub2, b'msg', sig) is False
