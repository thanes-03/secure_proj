import os
from datetime import datetime, timedelta
from app.models import User, OTPToken, Note, NoteKey, NoteAccess, AuditLog, Transaction
from app.extensions import db

def test_user_creation(db, app):
    with app.app_context():
        user = User(
            email='test@graduate.utm.my',
            password_hash='hashed',
            vault_salt=os.urandom(32),
            role='student',
        )
        db.session.add(user)
        db.session.commit()
        assert user.id is not None
        assert user.is_verified is False
        assert user.is_active is True

def test_note_creation(db, app):
    with app.app_context():
        user = User(email='n@graduate.utm.my', password_hash='h', vault_salt=os.urandom(32))
        db.session.add(user)
        db.session.flush()
        note = Note(
            owner_id=user.id,
            title_ciphertext=b'ct_title',
            body_ciphertext=b'ct_body',
            nonce=os.urandom(12),
            body_nonce=os.urandom(12),
        )
        db.session.add(note)
        db.session.commit()
        assert note.id is not None

def test_note_key_creation(db, app):
    with app.app_context():
        user = User(email='k@graduate.utm.my', password_hash='h', vault_salt=os.urandom(32))
        db.session.add(user)
        db.session.flush()
        note = Note(owner_id=user.id, title_ciphertext=b't', body_ciphertext=b'b', nonce=os.urandom(12), body_nonce=os.urandom(12))
        db.session.add(note)
        db.session.flush()
        nk = NoteKey(
            note_id=note.id, user_id=user.id,
            encrypted_note_key=b'key', key_nonce=os.urandom(12), key_type='vault',
        )
        db.session.add(nk)
        db.session.commit()
        assert nk.id is not None

def test_audit_log_creation(db, app):
    with app.app_context():
        log = AuditLog(user_id=None, action='login_failed', ip_address='127.0.0.1')
        db.session.add(log)
        db.session.commit()
        assert log.id is not None

def test_transaction_persists(app, db):
    import os
    from app.models import User, Transaction
    from app.extensions import db as _db
    from datetime import datetime
    with app.app_context():
        u1 = User(email='s@graduate.utm.my', password_hash='x', vault_salt=os.urandom(32))
        u2 = User(email='r@graduate.utm.my', password_hash='x', vault_salt=os.urandom(32))
        _db.session.add_all([u1, u2])
        _db.session.flush()
        tx = Transaction(
            note_id=None,
            sender_id=u1.id, receiver_id=u2.id,
            sender_email=u1.email, receiver_email=u2.email,
            created_at=datetime.utcnow().replace(microsecond=0),
            filename_ciphertext=b'ct', filename_nonce=os.urandom(12),
            kt_sender_wrapped=b'sw', kt_sender_nonce=os.urandom(12),
            kt_receiver_wrapped=b'rw', signature=b'sig',
        )
        _db.session.add(tx)
        _db.session.commit()
        got = Transaction.query.first()
        assert got.sender_email == 's@graduate.utm.my'
        assert got.receiver_email == 'r@graduate.utm.my'
        assert got.signature == b'sig'
