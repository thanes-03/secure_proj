import os
from app.extensions import db as _db, bcrypt
from app.crypto import (
    derive_vault_key, generate_rsa_keypair, aes_encrypt_sealed, rsa_verify,
)


def _make_verified_user(app, email, password='TxPass1!abcd'):
    vault_salt = os.urandom(32)
    vault_key = derive_vault_key(password, vault_salt)
    private_pem, public_pem = generate_rsa_keypair()
    from app.models import User
    with app.app_context():
        user = User(
            email=email,
            password_hash=bcrypt.generate_password_hash(password, rounds=4).decode(),
            vault_salt=vault_salt,
            rsa_public_key=public_pem.decode(),
            rsa_private_key_encrypted=aes_encrypt_sealed(vault_key, private_pem),
            is_verified=True, is_active=True,
        )
        _db.session.add(user)
        _db.session.commit()
        return user.id, vault_key


def _login(client, user_id, vault_key, is_admin=False):
    with client.session_transaction() as sess:
        sess['user_id'] = user_id
        sess['vault_key'] = vault_key.hex()
        sess['is_admin'] = is_admin


def _share(client, app, sender_id, sender_vault, recipient_email, title='Meeting notes'):
    _login(client, sender_id, sender_vault)
    client.post('/notes/new', data={'title': title, 'body': 'body text'})
    from app.models import Note
    with app.app_context():
        note = Note.query.filter_by(owner_id=sender_id).order_by(Note.id.desc()).first()
        note_id = note.id
    client.post(f'/notes/{note_id}/share',
                data={'recipient_email': recipient_email, 'permission': 'read'})
    return note_id


import json


def _get_tx_id(app):
    from app.models import Transaction
    with app.app_context():
        return Transaction.query.first().id


def test_share_creates_signed_transaction(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'sender@graduate.utm.my')
    r_id, _ = _make_verified_user(app, 'recv@graduate.utm.my')
    _share(client, app, s_id, s_vault, 'recv@graduate.utm.my', title='Budget')

    from app.models import Transaction, User
    from app.notes.routes import _receipt_message
    with app.app_context():
        tx = Transaction.query.first()
        assert tx is not None
        assert tx.sender_email == 'sender@graduate.utm.my'
        assert tx.receiver_email == 'recv@graduate.utm.my'
        # signature verifies against the sender's public key over the canonical message
        sender = User.query.get(tx.sender_id)
        msg = _receipt_message('Budget', tx.sender_email, tx.receiver_email, tx.created_at)
        assert rsa_verify(sender.rsa_public_key.encode(), msg, tx.signature) is True


def test_both_parties_download_and_verify(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'snd2@graduate.utm.my')
    r_id, r_vault = _make_verified_user(app, 'rcv2@graduate.utm.my')
    _share(client, app, s_id, s_vault, 'rcv2@graduate.utm.my', title='Report')
    tx_id = _get_tx_id(app)

    # sender downloads
    _login(client, s_id, s_vault)
    resp = client.get(f'/notes/transactions/{tx_id}/download')
    assert resp.status_code == 200
    assert resp.mimetype == 'application/json'
    payload = json.loads(resp.data)
    assert payload['file_name'] == 'Report'
    assert payload['sender'] == 'snd2@graduate.utm.my'
    assert payload['receiver'] == 'rcv2@graduate.utm.my'
    assert 'signature' in payload

    # receiver downloads
    _login(client, r_id, r_vault)
    resp = client.get(f'/notes/transactions/{tx_id}/download')
    assert resp.status_code == 200
    assert json.loads(resp.data)['file_name'] == 'Report'


def test_third_party_and_admin_cannot_download(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'snd3@graduate.utm.my')
    _make_verified_user(app, 'rcv3@graduate.utm.my')
    third_id, third_vault = _make_verified_user(app, 'third@graduate.utm.my')
    admin_id, admin_vault = _make_verified_user(app, 'admin@graduate.utm.my')
    _share(client, app, s_id, s_vault, 'rcv3@graduate.utm.my')
    tx_id = _get_tx_id(app)

    _login(client, third_id, third_vault)
    assert client.get(f'/notes/transactions/{tx_id}/download').status_code == 403

    _login(client, admin_id, admin_vault, is_admin=True)
    assert client.get(f'/notes/transactions/{tx_id}/download').status_code == 403


def test_download_rejects_tampered_signature(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'snd4@graduate.utm.my')
    r_id, r_vault = _make_verified_user(app, 'rcv4@graduate.utm.my')
    _share(client, app, s_id, s_vault, 'rcv4@graduate.utm.my')
    tx_id = _get_tx_id(app)

    from app.models import Transaction
    with app.app_context():
        tx = Transaction.query.get(tx_id)
        tx.signature = tx.signature[:-1] + bytes([tx.signature[-1] ^ 0xFF])
        _db.session.commit()

    _login(client, r_id, r_vault)
    resp = client.get(f'/notes/transactions/{tx_id}/download', follow_redirects=False)
    assert resp.status_code == 302  # refused → redirect with flash, not a JSON file


def test_download_handles_tampered_filename_ciphertext(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'snd5@graduate.utm.my')
    r_id, r_vault = _make_verified_user(app, 'rcv5@graduate.utm.my')
    _share(client, app, s_id, s_vault, 'rcv5@graduate.utm.my')
    tx_id = _get_tx_id(app)

    from app.models import Transaction
    with app.app_context():
        tx = Transaction.query.get(tx_id)
        corrupted = bytearray(tx.filename_ciphertext)
        corrupted[-1] ^= 0xFF
        tx.filename_ciphertext = bytes(corrupted)
        _db.session.commit()

    _login(client, r_id, r_vault)
    resp = client.get(f'/notes/transactions/{tx_id}/download', follow_redirects=False)
    assert resp.status_code == 302  # decryption failure -> redirect with flash, not a 500
    resp = client.get(f'/notes/transactions/{tx_id}/download', follow_redirects=True)
    assert resp.status_code == 200
    assert b'transactions' in resp.request.path.encode()


def test_transactions_list_scoped_to_parties(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'lsnd@graduate.utm.my')
    r_id, r_vault = _make_verified_user(app, 'lrcv@graduate.utm.my')
    other_id, other_vault = _make_verified_user(app, 'lother@graduate.utm.my')
    _share(client, app, s_id, s_vault, 'lrcv@graduate.utm.my', title='SharedDoc')

    # sender sees it under Sent
    _login(client, s_id, s_vault)
    resp = client.get('/notes/transactions')
    assert resp.status_code == 200
    assert b'SharedDoc' in resp.data
    assert b'lrcv@graduate.utm.my' in resp.data

    # receiver sees it too
    _login(client, r_id, r_vault)
    assert b'SharedDoc' in client.get('/notes/transactions').data

    # uninvolved user does not
    _login(client, other_id, other_vault)
    assert b'SharedDoc' not in client.get('/notes/transactions').data


def test_receipt_survives_note_edit(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'esnd@graduate.utm.my')
    r_id, r_vault = _make_verified_user(app, 'ercv@graduate.utm.my')
    note_id = _share(client, app, s_id, s_vault, 'ercv@graduate.utm.my', title='Original Title')
    tx_id = _get_tx_id(app)

    # owner edits the note (rotates its key/nonce)
    _login(client, s_id, s_vault)
    client.post(f'/notes/{note_id}/edit', data={'title': 'Changed Title', 'body': 'new'})

    # receipt still downloads and shows the SHARE-TIME title
    _login(client, r_id, r_vault)
    resp = client.get(f'/notes/transactions/{tx_id}/download')
    assert resp.status_code == 200
    assert json.loads(resp.data)['file_name'] == 'Original Title'


def test_receipt_survives_note_deletion(client, app, db):
    s_id, s_vault = _make_verified_user(app, 'dsnd@graduate.utm.my')
    r_id, r_vault = _make_verified_user(app, 'drcv@graduate.utm.my')
    note_id = _share(client, app, s_id, s_vault, 'drcv@graduate.utm.my', title='Doomed Note')
    tx_id = _get_tx_id(app)

    _login(client, s_id, s_vault)
    client.post(f'/notes/{note_id}/delete')

    from app.models import Transaction
    with app.app_context():
        tx = Transaction.query.get(tx_id)
        assert tx is not None
        assert tx.note_id is None

    _login(client, r_id, r_vault)
    resp = client.get(f'/notes/transactions/{tx_id}/download')
    assert resp.status_code == 200
    assert json.loads(resp.data)['file_name'] == 'Doomed Note'
