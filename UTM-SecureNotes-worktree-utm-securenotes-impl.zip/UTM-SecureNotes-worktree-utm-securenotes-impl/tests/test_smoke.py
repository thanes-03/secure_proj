def test_app_starts(client):
    response = client.get('/auth/login')
    assert response.status_code == 200
