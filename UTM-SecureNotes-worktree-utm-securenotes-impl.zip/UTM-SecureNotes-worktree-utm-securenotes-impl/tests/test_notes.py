import os
from unittest.mock import patch
from app.models import User, Note, NoteKey
from app.extensions import db as _db
from app.crypto import derive_vault_key, aes_decrypt, unwrap_key_with_vault


def _make_verified_user(app, db, email='notes@graduate.utm.my', password='NotePass1!xyz'):
    from app.crypto import generate_rsa_keypair, aes_encrypt_sealed
    vault_salt = os.urandom(32)
    vault_key = derive_vault_key(password, vault_salt)
    private_pem, public_pem = generate_rsa_keypair()
    from app.extensions import bcrypt
    with app.app_context():
        user = User(
            email=email,
            password_hash=bcrypt.generate_password_hash(password, rounds=4).decode(),
            vault_salt=vault_salt,
            rsa_public_key=public_pem.decode(),
            rsa_private_key_encrypted=aes_encrypt_sealed(vault_key, private_pem),
            is_verified=True,
            is_active=True,
        )
        _db.session.add(user)
        _db.session.commit()
        return user.id, vault_key


def _login_session(client, app, user_id, vault_key):
    with client.session_transaction() as sess:
        sess['user_id'] = user_id
        sess['vault_key'] = vault_key.hex()


def test_create_note(client, app, db):
    user_id, vault_key = _make_verified_user(app, db)
    _login_session(client, app, user_id, vault_key)
    resp = client.post('/notes/new', data={
        'title': 'My First Note',
        'body': 'Secret content here',
    }, follow_redirects=False)
    assert resp.status_code == 302
    with app.app_context():
        note = Note.query.filter_by(owner_id=user_id).first()
        assert note is not None
        nk = NoteKey.query.filter_by(note_id=note.id, user_id=user_id).first()
        assert nk is not None
        note_key = unwrap_key_with_vault(vault_key, nk.key_nonce, nk.encrypted_note_key)
        title = aes_decrypt(note_key, note.nonce, note.title_ciphertext).decode()
        assert title == 'My First Note'


def test_view_note(client, app, db):
    user_id, vault_key = _make_verified_user(app, db, email='view@graduate.utm.my')
    _login_session(client, app, user_id, vault_key)
    client.post('/notes/new', data={'title': 'View Test', 'body': 'Body'})
    with app.app_context():
        note = Note.query.filter_by(owner_id=user_id).first()
    resp = client.get(f'/notes/{note.id}')
    assert resp.status_code == 200
    assert b'View Test' in resp.data


def test_edit_note(client, app, db):
    user_id, vault_key = _make_verified_user(app, db, email='edit@graduate.utm.my')
    _login_session(client, app, user_id, vault_key)
    client.post('/notes/new', data={'title': 'Old Title', 'body': 'Old'})
    with app.app_context():
        note = Note.query.filter_by(owner_id=user_id).first()
    resp = client.post(f'/notes/{note.id}/edit', data={
        'title': 'New Title',
        'body': 'New content',
    }, follow_redirects=False)
    assert resp.status_code == 302
    with app.app_context():
        note = Note.query.get(note.id)
        nk = NoteKey.query.filter_by(note_id=note.id, user_id=user_id).first()
        note_key = unwrap_key_with_vault(vault_key, nk.key_nonce, nk.encrypted_note_key)
        assert aes_decrypt(note_key, note.nonce, note.title_ciphertext).decode() == 'New Title'


def test_delete_note(client, app, db):
    user_id, vault_key = _make_verified_user(app, db, email='del@graduate.utm.my')
    _login_session(client, app, user_id, vault_key)
    client.post('/notes/new', data={'title': 'To Delete', 'body': 'bye'})
    with app.app_context():
        note = Note.query.filter_by(owner_id=user_id).first()
    resp = client.post(f'/notes/{note.id}/delete', follow_redirects=False)
    assert resp.status_code == 302
    with app.app_context():
        assert Note.query.get(note.id) is None


def test_note_title_and_body_use_distinct_nonces(client, app, db):
    user_id, vault_key = _make_verified_user(app, db, email='distinctnonce@graduate.utm.my')
    _login_session(client, app, user_id, vault_key)
    client.post('/notes/new', data={'title': 'Nonce Test', 'body': 'Body content'})
    with app.app_context():
        note = Note.query.filter_by(owner_id=user_id).first()
        nk = NoteKey.query.filter_by(note_id=note.id, user_id=user_id).first()
        note_key = unwrap_key_with_vault(vault_key, nk.key_nonce, nk.encrypted_note_key)
        assert note.nonce != note.body_nonce
        assert aes_decrypt(note_key, note.body_nonce, note.body_ciphertext).decode() == 'Body content'


def test_cannot_view_other_users_note(client, app, db):
    user1_id, vault_key1 = _make_verified_user(app, db, email='u1@graduate.utm.my')
    user2_id, vault_key2 = _make_verified_user(app, db, email='u2@graduate.utm.my')
    _login_session(client, app, user1_id, vault_key1)
    client.post('/notes/new', data={'title': 'Private', 'body': 'secret'})
    with app.app_context():
        note = Note.query.filter_by(owner_id=user1_id).first()
    _login_session(client, app, user2_id, vault_key2)
    resp = client.get(f'/notes/{note.id}')
    assert resp.status_code == 403


def test_share_note_with_another_user(client, app, db):
    user1_id, vault_key1 = _make_verified_user(app, db, email='sharer@graduate.utm.my')
    user2_id, vault_key2 = _make_verified_user(app, db, email='recipient@graduate.utm.my')

    _login_session(client, app, user1_id, vault_key1)
    client.post('/notes/new', data={'title': 'Shared Note', 'body': 'shared content'})
    with app.app_context():
        note = Note.query.filter_by(owner_id=user1_id).first()

    resp = client.post(f'/notes/{note.id}/share', data={
        'recipient_email': 'recipient@graduate.utm.my',
        'permission': 'read',
    }, follow_redirects=False)
    assert resp.status_code == 302

    # Recipient can now view the note
    _login_session(client, app, user2_id, vault_key2)
    resp = client.get(f'/notes/{note.id}')
    assert resp.status_code == 200
    assert b'Shared Note' in resp.data


def test_share_rejects_non_utm_recipient(client, app, db):
    user_id, vault_key = _make_verified_user(app, db, email='sharer2@graduate.utm.my')
    _login_session(client, app, user_id, vault_key)
    client.post('/notes/new', data={'title': 'Note', 'body': 'body'})
    with app.app_context():
        note = Note.query.filter_by(owner_id=user_id).first()
    resp = client.post(f'/notes/{note.id}/share', data={
        'recipient_email': 'hacker@gmail.com',
        'permission': 'read',
    })
    assert resp.status_code == 200
    assert b'graduate.utm.my' in resp.data
