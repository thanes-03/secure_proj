import pytest
from app import create_app
from app.extensions import db as _db
from config import TestConfig

@pytest.fixture(scope='session')
def app():
    app = create_app(TestConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.drop_all()

@pytest.fixture(scope='function')
def db(app):
    with app.app_context():
        yield _db
        _db.session.remove()
        _db.drop_all()
        _db.create_all()

@pytest.fixture(scope='function')
def client(app, db):
    return app.test_client()
