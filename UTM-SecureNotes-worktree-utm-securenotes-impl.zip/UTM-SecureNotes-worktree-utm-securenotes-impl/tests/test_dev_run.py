import re
import pytest
from app.crypto import derive_vault_key
from app import create_app
from app.extensions import db as _db
from config import DevConfig


def test_register_echoes_otp_in_dev(monkeypatch, app, client, db):
    # Force dev echo on for this app instance
    monkeypatch.setitem(app.config, 'OTP_DEV_ECHO', True)
    resp = client.post('/auth/register', data={
        'email': 'echo@graduate.utm.my',
        'password': 'StrongPass1!xy',
    }, follow_redirects=True)
    # the 6-digit code is surfaced on the page in dev mode
    assert re.search(rb'\b\d{6}\b', resp.data)


@pytest.fixture()
def dev_app(tmp_path):
    class _SmokeConfig(DevConfig):
        SQLALCHEMY_DATABASE_URI = f'sqlite:///{tmp_path / "smoke.db"}'
        WTF_CSRF_ENABLED = False  # exercise the flow, not CSRF (see config.py TestConfig note)
        OTP_DEV_ECHO = True
    app = create_app(_SmokeConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.drop_all()


def _register_verify_login(app, client, email, password='SmokePass1!xy'):
    resp = client.post('/auth/register', data={
        'email': email, 'password': password,
    }, follow_redirects=True)
    otp = re.search(rb'\b(\d{6})\b', resp.data).group(1).decode()
    client.post('/auth/verify-otp', data={'token': otp}, follow_redirects=True)
    client.post('/auth/login', data={'email': email, 'password': password},
                follow_redirects=True)


def test_dev_golden_path(dev_app):
    client = dev_app.test_client()
    sender_client = dev_app.test_client()
    _register_verify_login(dev_app, sender_client, 'gsnd@graduate.utm.my')

    recv_client = dev_app.test_client()
    _register_verify_login(dev_app, recv_client, 'grcv@graduate.utm.my')

    # sender creates + shares a note
    sender_client.post('/notes/new', data={'title': 'Demo Note', 'body': 'hello'})
    from app.models import Note, Transaction
    with dev_app.app_context():
        note = Note.query.first()
        note_id = note.id
    sender_client.post(f'/notes/{note_id}/share',
                       data={'recipient_email': 'grcv@graduate.utm.my', 'permission': 'read'})

    with dev_app.app_context():
        tx_id = Transaction.query.first().id

    # receiver downloads the receipt
    resp = recv_client.get(f'/notes/transactions/{tx_id}/download')
    assert resp.status_code == 200
    import json
    assert json.loads(resp.data)['file_name'] == 'Demo Note'
