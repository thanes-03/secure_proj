import os
from app.models import User, AuditLog
from app.extensions import db as _db, bcrypt


def _make_admin(app, db):
    with app.app_context():
        user = User(
            email='admin@graduate.utm.my',
            password_hash=bcrypt.generate_password_hash('AdminPass1!', rounds=4).decode(),
            vault_salt=os.urandom(32),
            role='admin',
            is_verified=True,
            is_active=True,
        )
        _db.session.add(user)
        _db.session.commit()
        return user.id


def _make_student(app, db, email='stu@graduate.utm.my'):
    with app.app_context():
        user = User(
            email=email,
            password_hash='h',
            vault_salt=os.urandom(32),
            role='student',
            is_verified=True,
            is_active=True,
        )
        _db.session.add(user)
        _db.session.commit()
        return user.id


def _admin_session(client, user_id):
    with client.session_transaction() as sess:
        sess['user_id'] = user_id
        sess['vault_key'] = os.urandom(32).hex()


def test_admin_can_view_users(client, app, db):
    admin_id = _make_admin(app, db)
    _admin_session(client, admin_id)
    resp = client.get('/admin/users')
    assert resp.status_code == 200
    assert b'admin@graduate.utm.my' in resp.data


def test_admin_can_suspend_user(client, app, db):
    admin_id = _make_admin(app, db)
    stu_id = _make_student(app, db)
    _admin_session(client, admin_id)
    resp = client.post(f'/admin/users/{stu_id}/suspend', follow_redirects=False)
    assert resp.status_code == 302
    with app.app_context():
        user = User.query.get(stu_id)
        assert user.is_active is False


def test_admin_can_activate_user(client, app, db):
    admin_id = _make_admin(app, db)
    stu_id = _make_student(app, db, email='stu2@graduate.utm.my')
    with app.app_context():
        User.query.get(stu_id).is_active = False
        _db.session.commit()
    _admin_session(client, admin_id)
    resp = client.post(f'/admin/users/{stu_id}/activate', follow_redirects=False)
    assert resp.status_code == 302
    with app.app_context():
        assert User.query.get(stu_id).is_active is True


def test_admin_audit_log_visible(client, app, db):
    admin_id = _make_admin(app, db)
    with app.app_context():
        _db.session.add(AuditLog(user_id=admin_id, action='login', ip_address='127.0.0.1'))
        _db.session.commit()
    _admin_session(client, admin_id)
    resp = client.get('/admin/audit-logs')
    assert resp.status_code == 200
    assert b'login' in resp.data


def test_student_cannot_access_admin(client, app, db):
    stu_id = _make_student(app, db, email='stu3@graduate.utm.my')
    with client.session_transaction() as sess:
        sess['user_id'] = stu_id
        sess['vault_key'] = os.urandom(32).hex()
    resp = client.get('/admin/users')
    assert resp.status_code == 403
