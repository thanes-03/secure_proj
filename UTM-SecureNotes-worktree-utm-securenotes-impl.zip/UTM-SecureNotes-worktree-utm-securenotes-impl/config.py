import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ['SECRET_KEY']
    SQLALCHEMY_DATABASE_URI = os.environ['DATABASE_URL']
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = True
    OTP_DEV_ECHO = False
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ['MAIL_USERNAME']
    MAIL_PASSWORD = os.environ['MAIL_PASSWORD']
    MAIL_DEFAULT_SENDER = os.environ['MAIL_USERNAME']
    PERMANENT_SESSION_LIFETIME = 1800
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = True

class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    WTF_CSRF_ENABLED = False
    MAIL_SUPPRESS_SEND = True
    SECRET_KEY = 'test-secret-key-not-for-production'
    MAIL_USERNAME = 'test@test.com'
    MAIL_PASSWORD = 'test'
    # Test client uses plain HTTP (no TLS); a Secure cookie would not be
    # sent back by the test client, breaking session-dependent tests.
    SESSION_COOKIE_SECURE = False

class DevConfig(Config):
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///securenotes.db')
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-not-for-production')
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME', 'dev@example.com')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD', 'dev')
    MAIL_DEFAULT_SENDER = MAIL_USERNAME
    MAIL_SUPPRESS_SEND = True
    SESSION_COOKIE_SECURE = False
    OTP_DEV_ECHO = True
